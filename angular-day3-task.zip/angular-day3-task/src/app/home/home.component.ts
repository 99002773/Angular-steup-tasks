import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 location:string='';
 userBaseLocationAll:any=[];
 userBaseLocationBan:any=[];
 userBaseLocationHyd:any=[];
  constructor() { }
 users=[{name:'vinay',location:'Hyderabad'},{name:'vinay',location:'Banglore'},{name:'vamshi',location:'Hyderabad'},{name:'ramesh',location:'Hyderabad'},{name:'suresh',location:'Delhi'},{name:'ganesh',location:'Banglore'}]
  ngOnInit(): void {
  }
  onClickAllUsers()
  {
    
   
    this.location='all'
    this.users.forEach(element => {
    this.userBaseLocationAll.push(element)
    });
  }
  onClickBangloreUsers()
  {
    
   
    this.location='Banglore'
    this.users.forEach(element => {
      if(element.location=='Banglore')
      {
        this.userBaseLocationBan.push(element)
      }
    });
console.log('bn')
  }
  onClickHyderabadUsers(){
    
    
    this.location='Hyderabad'
    this.users.forEach(element => {
      if(element.location=='Hyderabad')
      {
        this.userBaseLocationHyd.push(element)
      }
    });
console.log('hyd')
  }
}
